//static PyObject *calcP(PyObject *self, PyObject *args);

int maxI(int a, int b);

double maxD(double a, double b);

int minI(int a, int b);

double minD(double a, double b);

//double abs(double x);
